window.SUPABASE_URL = 'https://kokmpbzfopkccghkukuj.supabase.co';
window.SUPABASE_ANON_KEY = 'sb_publishable_zWESEeBe3CQmBpPHQ71LBw_Po40M6mQ';
window.WHATSAPP_NUMBER = '9647800000000'; // غيّره إلى رقم واتساب المتجر لاحقاً
