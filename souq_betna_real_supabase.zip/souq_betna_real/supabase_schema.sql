-- سوق بيتنا - قاعدة بيانات Supabase الحقيقية
create extension if not exists "pgcrypto";

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text,
  phone text,
  role text not null default 'buyer' check (role in ('buyer','seller')),
  created_at timestamptz not null default now()
);

create table if not exists public.products (
  id uuid primary key default gen_random_uuid(),
  seller_id uuid references public.profiles(id) on delete set null,
  name text not null,
  category text not null,
  price numeric(12,2) not null default 0 check (price >= 0),
  old_price numeric(12,2),
  description text,
  image_url text,
  stock integer not null default 0 check (stock >= 0),
  is_used boolean not null default false,
  created_at timestamptz not null default now()
);

create table if not exists public.orders (
  id uuid primary key default gen_random_uuid(),
  buyer_id uuid references public.profiles(id) on delete set null,
  customer_name text,
  phone text,
  address text,
  status text not null default 'new' check (status in ('new','confirmed','shipped','delivered','cancelled')),
  total numeric(12,2) not null default 0,
  whatsapp_order_no text,
  created_at timestamptz not null default now()
);

create table if not exists public.order_items (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references public.orders(id) on delete cascade,
  product_id uuid references public.products(id) on delete set null,
  product_name text not null,
  quantity integer not null check (quantity > 0),
  unit_price numeric(12,2) not null check (unit_price >= 0)
);

alter table public.profiles enable row level security;
alter table public.products enable row level security;
alter table public.orders enable row level security;
alter table public.order_items enable row level security;

-- إنشاء ملف المستخدم تلقائياً عند التسجيل. الدور يؤخذ مرة واحدة من بيانات التسجيل.
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  insert into public.profiles (id, full_name, phone, role)
  values (
    new.id,
    coalesce(new.raw_user_meta_data->>'full_name', ''),
    coalesce(new.raw_user_meta_data->>'phone', ''),
    case when new.raw_user_meta_data->>'role' = 'seller' then 'seller' else 'buyer' end
  )
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
after insert on auth.users
for each row execute procedure public.handle_new_user();

-- السياسات: حذف/تحديث السياسة القديمة إن وجدت ثم إنشاء النسخة الصحيحة.
drop policy if exists "public read products" on public.products;
create policy "public read products" on public.products for select using (true);

drop policy if exists "seller insert own products" on public.products;
create policy "seller insert own products" on public.products for insert to authenticated
with check (
  auth.uid() = seller_id and
  exists (select 1 from public.profiles p where p.id = auth.uid() and p.role = 'seller')
);

drop policy if exists "seller update own products" on public.products;
create policy "seller update own products" on public.products for update to authenticated
using (auth.uid() = seller_id and exists (select 1 from public.profiles p where p.id = auth.uid() and p.role = 'seller'))
with check (auth.uid() = seller_id and exists (select 1 from public.profiles p where p.id = auth.uid() and p.role = 'seller'));

drop policy if exists "seller delete own products" on public.products;
create policy "seller delete own products" on public.products for delete to authenticated
using (auth.uid() = seller_id and exists (select 1 from public.profiles p where p.id = auth.uid() and p.role = 'seller'));

drop policy if exists "own profile read" on public.profiles;
create policy "own profile read" on public.profiles for select to authenticated using (auth.uid() = id);

drop policy if exists "own profile insert" on public.profiles;
create policy "own profile insert" on public.profiles for insert to authenticated with check (auth.uid() = id);
-- لا توجد سياسة update للملفات الشخصية حتى لا يستطيع المستخدم تغيير buyer إلى seller.

drop policy if exists "buyer create own orders" on public.orders;
create policy "buyer create own orders" on public.orders for insert to authenticated
with check (auth.uid() = buyer_id);

drop policy if exists "buyer read own orders" on public.orders;
create policy "buyer read own orders" on public.orders for select to authenticated
using (
  auth.uid() = buyer_id or
  exists (
    select 1 from public.order_items oi
    join public.products p on p.id = oi.product_id
    where oi.order_id = orders.id and p.seller_id = auth.uid()
  )
);

drop policy if exists "seller update relevant orders" on public.orders;
create policy "seller update relevant orders" on public.orders for update to authenticated
using (
  exists (
    select 1 from public.order_items oi
    join public.products p on p.id = oi.product_id
    where oi.order_id = orders.id and p.seller_id = auth.uid()
  )
)
with check (true);

drop policy if exists "buyer create order items" on public.order_items;
create policy "buyer create order items" on public.order_items for insert to authenticated
with check (exists (select 1 from public.orders o where o.id = order_id and o.buyer_id = auth.uid()));

drop policy if exists "buyer read order items" on public.order_items;
create policy "buyer read order items" on public.order_items for select to authenticated
using (
  exists (select 1 from public.orders o where o.id = order_id and o.buyer_id = auth.uid())
  or exists (
    select 1 from public.products p where p.id = product_id and p.seller_id = auth.uid()
  )
);

insert into storage.buckets (id, name, public)
values ('product-images', 'product-images', true)
on conflict (id) do update set public = true;

drop policy if exists "public read product images" on storage.objects;
create policy "public read product images" on storage.objects for select
using (bucket_id = 'product-images');

drop policy if exists "authenticated upload product images" on storage.objects;
create policy "authenticated upload product images" on storage.objects for insert to authenticated
with check (bucket_id = 'product-images');

drop policy if exists "authenticated update product images" on storage.objects;
create policy "authenticated update product images" on storage.objects for update to authenticated
using (bucket_id = 'product-images') with check (bucket_id = 'product-images');

drop policy if exists "authenticated delete product images" on storage.objects;
create policy "authenticated delete product images" on storage.objects for delete to authenticated
using (bucket_id = 'product-images');

-- منتجات تجريبية تظهر في المتجر فوراً، ويمكن حذفها لاحقاً من لوحة البائع/قاعدة البيانات.
insert into public.products (name, category, price, old_price, description, stock, is_used)
select * from (values
('كريم فيتامين C للوجه','العناية بالبشرة',25,32,'كريم مرطب بفيتامين C مناسب للاستخدام اليومي.',30,false),
('شامبو للعناية بالشعر','العناية بالشعر',12,18,'تركيبة لطيفة للعناية بالشعر للاستخدام اليومي.',30,false),
('قلاية هوائية 6 لتر','الأجهزة المنزلية',85,120,'قلاية هوائية بسعة 6 لتر وتحكم رقمي.',15,false),
('سماعات لاسلكية','الأجهزة الإلكترونية',45,65,'سماعات لاسلكية بعلبة شحن وتصميم مريح.',20,false),
('طقم ملابس رجالي','الملابس',35,55,'طقم عملي وأنيق للاستخدام اليومي.',12,false),
('جاكيت شتوي مستعمل','الأغراض المستعملة',18,28,'قطعة مستعملة بحالة ممتازة ونظيفة.',5,true)
) as v(name,category,price,old_price,description,stock,is_used)
where not exists (select 1 from public.products limit 1);
